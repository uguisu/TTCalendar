package com.opensymphony.xwork2;

/**
 * <code>UserSpecifiedDefaultAction</code>
 *
 * @author <a href="mailto:hermanns@aixcept.de">Rainer Hermanns</a>
 * @version $Id$
 */
public class UserSpecifiedDefaultAction extends ActionSupport {
}
