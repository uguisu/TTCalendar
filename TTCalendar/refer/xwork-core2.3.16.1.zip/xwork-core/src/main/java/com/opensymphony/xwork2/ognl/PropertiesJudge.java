package com.opensymphony.xwork2.ognl;

public interface PropertiesJudge {

    boolean acceptProperty(String propertyName);

}
